define(['./Base'], function (Base) {
    var c2 = new Base('Controller 2');
    return c2;
});
