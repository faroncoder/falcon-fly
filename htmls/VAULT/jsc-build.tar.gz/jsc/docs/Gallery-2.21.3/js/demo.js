/*
 * blueimp Gallery Demo JS
 * https://github.com/blueimp/Gallery
 *
 * Copyright 2013, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* global blueimp, $ */

$( function()
{
  'use strict'

  // Load demo images from flickr:
  // $.ajax(
  // {
  //   // Flickr API is SSL only:
  //   // https://code.flickr.net/2014/04/30/flickr-api-going-ssl-only-on-june-27th-2014/
  //   url: 'https://api.flickr.com/services/rest/',
  //   data:
  //   {
  //     format: 'json',
  //     method: 'flickr.interestingness.getList',
  //     api_key: '7617adae70159d09ba78cfec73c13be3' // jshint ignore:line
  //   },
  //   dataType: 'jsonp',
  //   jsonp: 'jsoncallback'
  // } ).done( function( result )
  // {
  //   var carouselLinks = []
  //   var linksContainer = $( '#links' )
  //   var baseUrl
  //     // Add the demo images as links with thumbnails to the page:
  //   $.each( result.photos.photo, function( index, photo )
  //     {
  //       baseUrl = 'https://farm' + photo.farm + '.static.flickr.com/' +
  //         photo.server + '/' + photo.id + '_' + photo.secret
  //       $( '<a/>' )
  //         .append( $( '<img>' ).prop( 'src', baseUrl + '_s.jpg' ) )
  //         .prop( 'href', baseUrl + '_b.jpg' )
  //         .prop( 'title', photo.title )
  //         .attr( 'data-gallery', '' )
  //         .appendTo( linksContainer )
  //       carouselLinks.push(
  //       {
  //         href: baseUrl + '_c.jpg',
  //         title: photo.title
  //       } )
  //     } )
  //     // Initialize the Gallery as image carousel:
  //   blueimp.Gallery( carouselLinks,
  //   {
  //     container: '#blueimp-image-carousel',
  //     carousel: true
  //   } )
  // } )


  // Initialize the Gallery as video carousel:
  blueimp.Gallery( [
    {
      title: '0000',
      href: 'http://192.168.1.6:7780/0000.mp4',
      type: 'video/mp4',
      poster: 'http://192.168.1.6:7781/0000-5.png'
    },
    {
      title: '0001',
      href: 'http://192.168.1.6:7780/0001.mp4',
      type: 'video/mp4',
      poster: 'http://192.168.1.6:7781/0001-5.png'
    },
    {
      title: '0002',
      href: 'http://192.168.1.6:7780/0002.mp4',
      type: 'video/mp4',
      poster: 'http://192.168.1.6:7781/0002-5.png'
    },
    {
      title: '0003',
      href: 'http://192.168.1.6:7780/0003.mp4',
      type: 'video/mp4',
      poster: 'http://192.168.1.6:7781/0003-5.png'
    },
    {
      title: '0004',
      href: 'http://192.168.1.6:7780/0004.mp4',
      type: 'video/mp4',
      poster: 'http://192.168.1.6:7781/0004-5.png'
    }
  ],
  {
    container: '#blueimp-video-carousel',
    carousel: true
  } )
} )

