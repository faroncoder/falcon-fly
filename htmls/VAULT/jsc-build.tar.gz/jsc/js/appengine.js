$.getScript('https://cdnjs.cloudflare.com/ajax/libs/tether/1.3.7/js/tether.min.js', function(data, textStatus) {
	console.log('tether.js loaded', textStatus);
	$.getScript('https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js', function(data, textStatus) {
		console.log('jquery-ui.min.js loaded', textStatus); });
	$.getScript('https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.5/js/bootstrap.min.js', function(data, textStatus) {
		console.log('bootstrap.min.js loaded', textStatus); });
	});

$.getScript('./.jsc/js/angular.min.js', function(data, textStatus) {
		console.log('angular.min.js loaded', textStatus);
});
$.getScript('https://cdnjs.cloudflare.com/ajax/libs/jStorage/0.4.12/jstorage.min.js', function(data, textStatus) {
		console.log('jstorage.js loaded', textStatus);
});

$.getScript('./.jsc/js/jquery.lazyload.min.js', function(data, textStatus) {
		console.log('jquery.lazyload.min.js loaded', textStatus);
	});

$.getScript('./.jsc/js/jstorage.js', function(data, textStatus) {
		console.log('jstorage.js loaded', textStatus);
	});

$.getScript('./.jsc/js/socket.io.js', function(data, textStatus) {
		console.log('socket.io.js loaded', textStatus);
	});

$.getScript('./.jsc/js/mediaelementplayer.min.js', function(data, textStatus) {
		console.log('mediaelementplayer.min.js loaded', textStatus);
	});

$.getScript('./.jsc/js/mediaelement-and-player.min.js', function(data, textStatus) {
		console.log('mediaelement-and-player.min.js loaded', textStatus);
	});

$.getScript('./.jsc/js/jquery.scrollstop.min.js', function(data, textStatus) {
		console.log('jquery.scrollstop.min.js loaded', textStatus);
	});

$.getScript('./.jsc/js/mediaelement.min.js', function(data, textStatus) {
		console.log('mediaelement.min.js loaded', textStatus);
	});
