$(function(data, textStatus) {
    // BEGIN CUSTOM SCRIPTING //


    // END CUSTOM SCRIPTING //
}); // end function