faron-formajaxer
================

Form formulator and code generator

Demo: http://faronintel.ca/formstrap/
