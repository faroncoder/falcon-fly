Meteor.startup(function() {

  AccountsEntry.config({
    signupCode: null
  });

});
