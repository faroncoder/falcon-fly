Template.home.rendered = function() {

};
