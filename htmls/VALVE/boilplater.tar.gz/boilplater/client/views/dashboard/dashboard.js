Template.dashboard.rendered = function() {

};
